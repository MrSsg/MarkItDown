# MarkItDownDesk -- Developer Log

Version: v1.0 | PySide6 (Qt 6.11) | PyInstaller

---

## Project Structure

  markitdown-desktop/
  +-- main.py                  # Entry + system tray
  +-- build.spec               # PyInstaller config
  +-- requirements.txt         # Dependencies
  +-- start_markitdown.bat     # Quick-launch
  +-- app/
  |   +-- settings.py          # QSettings persistence
  |   +-- history.py           # JSON history (50 entries)
  |   +-- theme.py             # Dark/light/system theme
  |   +-- worker.py            # Background conversion (QThread)
  |   +-- main_window.py       # Main window + settings dialog
  |   +-- float_window.py      # Float window (edge-snap/drag-drop)
  |   +-- styles/
  |       +-- dark.qss
  |       +-- light.qss
  +-- assets/

---

## Module Design

### main.py
- Creates QApplication, instantiates all modules
- Connects float drag -> main convert, settings, etc.
- System tray icon with right-click menu
- setQuitOnLastWindowClosed(False) for Tool window

### settings.py
- QSettings wrapper, persists to Windows registry
- Keys: save path, theme mode, float state, window geometry, history max
- Call sync() after changes

### history.py
- JSON file in %%LOCALAPPDATA%%/MarkItDownDesk/history.json
- Fields: path, name, size, type, timestamp, preview
- Dedup by file_path, max 50 by default

### theme.py
- Loads QSS from app/styles/{dark,light}.qss
- Modes: system (auto), dark, light
- Qt 6.5+ colorScheme detection, fallback to registry
- _resource_path handles PyInstaller sys._MEIPASS

### worker.py (most critical)
- Pattern: Worker Object + moveToThread
- Flow: start_convert -> QThread + _ConvertTask -> worker.run()
- markitdown import is INSIDE run() to defer to worker thread
- Old thread is quit()+wait(3000) before new thread
- Cross-thread signals use explicit QueuedConnection
- Cleanup: deleteLater on worker and thread completion

### main_window.py
- Layout: MenuBar > ToolBar > Splitter(Left|Right) > StatusBar
- Left: file info + history list
- Right: QTextBrowser (Markdown->HTML via markdown+pygments)
- Error dialog uses QMessageBox.warning(None, ...) to avoid float blocking

### float_window.py
- States: COLLAPSED (48x48) > HOVER (64x180) > ACTIVE (260x380)
- Edge snap: distance to all 4 edges of all monitors (<20px snap, >50px detach)
- Flags: StayOnTopHint | FramelessWindowHint | Tool
- WA_TranslucentBackground for QPainter rounded corners
- All content self-painted (no child widgets)
- setAcceptDrops(False) when COLLAPSED

---

## Known Issues
- Audio needs ffmpeg/avconv external binary
- youtube-transcript-api not on Python 3.14 yet
- No progress bar for large files
- OCR plugin not integrated
- exiftool not bundled, silent fallback
- No cancel button

---

## Build
  pip install -r requirements.txt
  pip install -e ../packages/markitdown
  pip install pandas openpyxl pdfminer.six pdfplumber ...
  pyinstaller build.spec

Output: dist/MarkItDownDesk.exe

---

Last updated: 2026-07-13
## Bug Fix Log (2026-07-13)

**Problem:** App stuck on converting... after file drop.

**Root causes:**
1. markitdown not installed -> ImportError caught, but error dialog hidden behind float window
2. Worker Object pattern + QueuedConnection unreliable on this PySide6/Python 3.14

**Fix:**
- Rewrote worker.py: QThread subclass pattern replaces moveToThread+QueuedConnection
- QMessageBox.warning(None, ...) instead of .warning(self, ...)
- Previous-thread cleanup (quit+wait+terminate)

**Verified:** XLSX: 33960 chars, signal delivery ~1450ms

## v0.7.0 - Layout Overhaul (2026-07-13)

**Core change:** Replaced fixed card layout with QSplitter-based resizable panels.

**New class:** `ResettableSplitter(QSplitter)` with double-click reset to default
proportions, hover cursor change (SplitH/SplitV), and minimum size enforcement.

**Layout:**
- Outer: vertical splitter (top 60% | history panel 40%)
- Inner: horizontal splitter (upload | options | preview = 1:1:1)
- Each panel minimum width: 220px; history minimum height: 180px

**Persistence:** Splitter states saved via `window_splitter_outer` / `window_splitter_inner`
settings keys on close, restored on startup.

**QSS:** Added `QSplitter::handle` styles to both dark and light themes.
Handle turns #407BFF with resize cursor on hover via event filter.

**Settings:** Replaced single `window_splitter` property with two keys
(`window_splitter_outer`, `window_splitter_inner`) in AppSettings.

## App Icon Applied (2026-07-14)

User-designed icon with stylized MC logo applied to the application.

**Assets:**
- icons/icon_16.png (16x16, system tray)
- icons/icon_32.png (32x32, window title bar)
- icons/icon_128.png (128x128, Alt+Tab / high-res)
- assets/app_icon.ico (multi-resolution, PyInstaller executable icon)

**Changes:**
- Removed programmatic `_make_app_icon()` from main.py
- Load icon PNGs via QIcon.addFile() with absolute paths
- build.spec: icon set to app_icon.ico; PNGs added as data files
- Unused imports (QPixmap, QPainter, QColor) cleaned up

## Float Icon + Hover/Drag Feedback (2026-07-14)

**Float icon applied:** Custom MC logo icons in 16/32/128px.

**Hover feedback:**
- Hovered state flag tracked in enter/leave event
- Border turns #407BFF on hover (from default gray)
- Background slightly brightens on hover
- Border width increases from 1px to 2px

**Drag feedback:**
- Drop shadow drawn behind the window while dragging
- Border becomes bold #407BFF (3px) while dragging
- Drag state cleared on mouse release

**Collapsed state hover:**
- Icon area background brightens when mouse passes over
- Transition handled via paintEvent repaint on hover change
- All visual states exposed through `_hovered` / `_dragging` flags

## v0.8.0 — Float Icon + Hover/Drag Feedback (2026-07-14)

- Float window now displays your custom MC logo PNG at all states
- Hover: border turns blue + background brightens
- Drag: drop shadow + bold blue border
- Collapsed hover: same glow feedback as expanded

