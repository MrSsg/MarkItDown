# SPDX-License-Identifier: MIT
__version__ = "0.8.0"
__app_name__ = "MarkItDownDesk"
