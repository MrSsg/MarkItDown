# SPDX-License-Identifier: MIT

import os, time, html as html_mod

from PySide6.QtCore import (Qt, Slot, QSize, QPropertyAnimation, QEvent,
    QEasingCurve, Signal)
from PySide6.QtGui import (QAction, QClipboard, QFont, QColor,
    QPainter, QPixmap, QIcon, QDragEnterEvent, QDropEvent,
    QDragLeaveEvent, QDragMoveEvent)
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFrame, QSplitter,
    QTextBrowser, QListWidget, QListWidgetItem, QLabel, QPushButton,
    QStatusBar, QFileDialog, QMessageBox, QDialog, QDialogButtonBox,
    QRadioButton, QCheckBox, QSlider, QSpinBox, QComboBox, QFormLayout,
    QGroupBox, QSizePolicy, QApplication, QStyle, QGraphicsDropShadowEffect)

from .worker import ConvertWorker
from .history import HistoryManager, HistoryEntry
from .settings import AppSettings
from .theme import ThemeManager
from app.__about__ import __version__, __app_name__
TOPBAR_HEIGHT = 64
CARD_RADIUS = 16


class TopBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("TopBar")
        self.setFixedHeight(TOPBAR_HEIGHT)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(0)
        left = QHBoxLayout()
        left.setSpacing(6)
        logo = QLabel("MD")
        logo.setFixedSize(34, 34)
        logo.setAlignment(Qt.AlignCenter)
        f = logo.font(); f.setBold(True); f.setPointSize(12)
        logo.setFont(f)
        logo.setStyleSheet("background: #407BFF; color: white; border-radius: 9px;")
        left.addWidget(logo)
        name_lbl = QLabel("MarkConvert Desk")
        name_lbl.setStyleSheet("font-size: 18px; font-weight: 600; padding: 0 4px;")
        left.addWidget(name_lbl)
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setFixedWidth(1)
        sep.setStyleSheet("background: palette(mid);")
        left.addWidget(sep)
        for nav_id, txt in [("file", "  文件"), ("history", "  历史"), ("settings", "  设置")]:
            b = QPushButton(txt)
            b.setObjectName("navBtn")
            left.addWidget(b)
        left.addStretch()
        layout.addLayout(left, 1)
        center = QHBoxLayout()
        center.setSpacing(6)
        self._tool_btns = {}
        tool_defs = [
            ("toolOpen", chr(0x1F4C2) + " 打开"),
            ("toolConvert", chr(0x1F504) + " 转换"),
            ("toolCopy", chr(0x1F4CB) + " 复制"),
            ("toolMD", "MD"),
            ("toolClear", chr(0x1F5D1) + " 清空"),
        ]
        for obj_id, txt in tool_defs:
            b = QPushButton(txt)
            b.setObjectName("toolBtn")
            b.setFixedHeight(36)
            center.addWidget(b)
            self._tool_btns[obj_id] = b
        layout.addLayout(center)
        right = QHBoxLayout()
        right.setSpacing(4)
        self._theme_btn = QPushButton(chr(0x2600))
        self._theme_btn.setObjectName("iconBtn")
        self._theme_btn.setFixedSize(38, 38)
        self._theme_btn.setToolTip("切换主题")
        right.addWidget(self._theme_btn)
        self._settings_btn = QPushButton(chr(0x2699))
        self._settings_btn.setObjectName("iconBtn")
        self._settings_btn.setFixedSize(38, 38)
        self._settings_btn.setToolTip("设置")
        right.addWidget(self._settings_btn)
        layout.addLayout(right)

    def tool_button(self, name):
        return self._tool_btns.get(name)
    @property
    def theme_btn(self):
        return self._theme_btn
    @property
    def settings_btn(self):
        return self._settings_btn
    def update_theme_icon(self, is_dark):
        self._theme_btn.setText(chr(0x2602) if is_dark else chr(0x2600))


class CollapsibleCard(QFrame):
    def __init__(self, title="", parent=None, collapsed=False):
        super().__init__(parent)
        self.setObjectName("CardWidget")
        self._expanded = not collapsed
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(30)
        shadow.setColor(QColor(0, 0, 0, 18))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        hdr = QWidget()
        hdr.setFixedHeight(52)
        hdr.setStyleSheet("background: transparent;")
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(20, 0, 12, 0)
        self._title_lbl = QLabel(title)
        self._title_lbl.setObjectName("cardTitle")
        hl.addWidget(self._title_lbl)
        hl.addStretch()
        self._collapse_btn = QPushButton(chr(9660))
        self._collapse_btn.setObjectName("collapseBtn")
        self._collapse_btn.setFixedSize(28, 28)
        self._collapse_btn.clicked.connect(self.toggle)
        hl.addWidget(self._collapse_btn)
        layout.addWidget(hdr)
        self._content = QWidget()
        self._content.setObjectName("cardContent")
        self._clayout = QVBoxLayout(self._content)
        self._clayout.setContentsMargins(20, 4, 20, 20)
        self._clayout.setSpacing(12)
        layout.addWidget(self._content)
        if collapsed:
            self._content.setVisible(False)

    def content_layout(self):
        return self._clayout
    def set_title(self, text):
        self._title_lbl.setText(text)
    def toggle(self):
        self._expanded = not self._expanded
        self._content.setVisible(self._expanded)
        self._collapse_btn.setText(chr(9650) if self._expanded else chr(9660))

class DropArea(QWidget):
    file_dropped = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("dropArea")
        self.setAcceptDrops(True)
        self.setMinimumHeight(160)
        self._drag_over = False
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(8)
        icon_lbl = QLabel(chr(0x1F4C1))
        icon_lbl.setObjectName("dropIcon")
        icon_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(icon_lbl)
        text_lbl = QLabel("拖拽文件到这里，或点击浏览")
        text_lbl.setObjectName("dropText")
        text_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(text_lbl)
        hint_lbl = QLabel("支持 PDF、DOCX、XLSX、PPTX、TXT、图片等多种格式")
        hint_lbl.setObjectName("dropHint")
        hint_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(hint_lbl)
        self._browse_btn = QPushButton("浏览文件...")
        self._browse_btn.setObjectName("secondaryBtn")
        self._browse_btn.setFixedWidth(160)
        layout.addWidget(self._browse_btn, 0, Qt.AlignCenter)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            self._drag_over = True
            self.setProperty("dragOver", True)
            self.style().unpolish(self)
            self.style().polish(self)
            event.acceptProposedAction()

    def dragLeaveEvent(self, event):
        self._drag_over = False
        self.setProperty("dragOver", False)
        self.style().unpolish(self)
        self.style().polish(self)

    def dropEvent(self, event):
        self._drag_over = False
        self.setProperty("dragOver", False)
        self.style().unpolish(self)
        self.style().polish(self)
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.file_dropped.emit(paths)
        event.acceptProposedAction()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            mw = self.window()
            if hasattr(mw, "_open_file"):
                mw._open_file()

    @property
    def browse_btn(self):
        return self._browse_btn

class HistoryPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("HistoryPanel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(8)
        hdr = QHBoxLayout()
        title_lbl = QLabel("转换历史")
        title_lbl.setStyleSheet("font-size: 15px; font-weight: 600;")
        hdr.addWidget(title_lbl)
        hdr.addStretch()
        self._count_lbl = QLabel("")
        self._count_lbl.setStyleSheet("color: palette(mid); font-size: 12px;")
        hdr.addWidget(self._count_lbl)
        self._clear_btn = QPushButton("清空")
        self._clear_btn.setObjectName("histActionBtn")
        self._clear_btn.setStyleSheet("color: #F53F3F; background: transparent; border: none; padding: 4px 12px; font-size: 12px;")
        hdr.addWidget(self._clear_btn)
        layout.addLayout(hdr)
        self._list = QListWidget()
        self._list.setMinimumHeight(80)
        self._list.setMaximumHeight(160)
        layout.addWidget(self._list)

    @property
    def list_widget(self):
        return self._list
    @property
    def clear_btn(self):
        return self._clear_btn
    def set_count(self, n):
        self._count_lbl.setText(f"{n} records" if n else "")

class SettingsDialog(QDialog):
    def __init__(self, settings, theme_mgr, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._theme = theme_mgr
        self.setWindowTitle("偏好设置")
        self.setMinimumWidth(460)
        self._build_ui()
        self._load_values()

    def _build_ui(self):
        l = QVBoxLayout(self)
        l.setSpacing(16)
        g1 = QGroupBox("保存路径")
        g1l = QVBoxLayout(g1)
        self._path_lbl = QLabel(self._settings.default_save_path or "（未设置）")
        self._path_lbl.setWordWrap(True)
        br = QHBoxLayout()
        browse_btn = QPushButton("浏览...")
        browse_btn.clicked.connect(self._browse_path)
        self._ask_cb = QCheckBox("每次询问")
        self._ask_cb.toggled.connect(lambda c: browse_btn.setEnabled(not c))
        br.addWidget(browse_btn); br.addWidget(self._ask_cb); br.addStretch()
        g1l.addWidget(self._path_lbl); g1l.addLayout(br)
        l.addWidget(g1)
        g2 = QGroupBox("主题")
        g2l = QVBoxLayout(g2)
        self._sys_rb = QRadioButton("跟随系统")
        self._dark_rb = QRadioButton("深色")
        self._light_rb = QRadioButton("浅色")
        g2l.addWidget(self._sys_rb); g2l.addWidget(self._dark_rb); g2l.addWidget(self._light_rb)
        l.addWidget(g2)
        g3 = QGroupBox("历史记录")
        g3l = QVBoxLayout(g3)
        hr = QHBoxLayout()
        hr.addWidget(QLabel("最大条数："))
        self._max_spin = QSpinBox(); self._max_spin.setRange(10, 200)
        hr.addWidget(self._max_spin); hr.addStretch()
        g3l.addLayout(hr)
        clear_btn = QPushButton("清空历史")
        clear_btn.clicked.connect(self._clear_history)
        g3l.addWidget(clear_btn)
        l.addWidget(g3)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._save_values); btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        l.addWidget(btns)

    def _load_values(self):
        mode = self._settings.theme_mode or "system"
        if mode == "system": self._sys_rb.setChecked(True)
        elif mode == "dark": self._dark_rb.setChecked(True)
        else: self._light_rb.setChecked(True)
        self._ask_cb.setChecked(self._settings.ask_save_each_time)
        if not self._settings.ask_save_each_time:
            self._path_lbl.setText(self._settings.default_save_path or "（未设置）")
        self._max_spin.setValue(self._settings.max_history)

    def _save_values(self):
        if self._sys_rb.isChecked(): self._settings.theme_mode = "system"
        elif self._dark_rb.isChecked(): self._settings.theme_mode = "dark"
        else: self._settings.theme_mode = "light"
        self._settings.ask_save_each_time = self._ask_cb.isChecked()
        self._settings.max_history = self._max_spin.value()
        self._settings.sync()
        self._theme.set_mode(self._settings.theme_mode)

    def _browse_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择默认保存路径")
        if path:
            self._settings.default_save_path = path
            self._path_lbl.setText(path)
            self._settings.sync()

    def _clear_history(self):
        parent = self.parent()
        if hasattr(parent, "history_mgr"):
            parent.history_mgr.clear()



class ResettableSplitter(QSplitter):
    """QSplitter with double-click reset and hover cursor."""
    def __init__(self, orientation, default_sizes=None, parent=None):
        super().__init__(orientation, parent)
        self._default_sizes = default_sizes
        self.setHandleWidth(4)

    def showEvent(self, event):
        super().showEvent(event)
        for i in range(self.count()):
            self.handle(i).installEventFilter(self)

    def eventFilter(self, obj, event):
        for i in range(self.count()):
            if self.handle(i) is obj:
                if event.type() == QEvent.Type.Enter:
                    obj.setCursor(Qt.SplitHCursor if self.orientation() == Qt.Horizontal else Qt.SplitVCursor)
                elif event.type() == QEvent.Type.Leave:
                    obj.setCursor(Qt.ArrowCursor)
                elif event.type() == QEvent.Type.MouseButtonDblClick:
                    if self._default_sizes:
                        self.setSizes(self._default_sizes)
                    return True
                break
        return super().eventFilter(obj, event)

class MainWindow(QMainWindow):
    def __init__(self, settings, theme_mgr, history_mgr):
        super().__init__()
        self._settings = settings
        self._theme = theme_mgr
        self.history_mgr = history_mgr
        self._current_file = None
        self._current_markdown = ""
        self._convert_start = 0.0
        self._file_list = []

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Top Bar
        self._topbar = TopBar()
        root.addWidget(self._topbar)

        # Content area
        cw = QWidget()
        cw.setContentsMargins(16, 16, 16, 0)
        cl = QVBoxLayout(cw)
        cl.setSpacing(12)

        # Three equal-width cards in a horizontal splitter
        self._inner_splitter = ResettableSplitter(Qt.Horizontal, default_sizes=[333, 333, 334])

        # Card 1: Upload
        self._upload_card = CollapsibleCard("上传文件")
        self._drop_area = DropArea()
        self._upload_card.content_layout().addWidget(self._drop_area)
        self._file_list_w = QListWidget()
        self._file_list_w.setMaximumHeight(120)
        self._upload_card.content_layout().addWidget(self._file_list_w)
        self._upload_card.setMinimumWidth(220)
        self._inner_splitter.addWidget(self._upload_card)

        # Card 2: Options
        self._options_card = CollapsibleCard("转换选项")
        ol = self._options_card.content_layout()
        hl = QHBoxLayout()
        hl.addWidget(QLabel("标题层级:"))
        self._heading_cb = QComboBox()
        self._heading_cb.addItems(["h1", "h2", "h3", "h4", "h5", "h6"])
        self._heading_cb.setCurrentIndex(1)
        hl.addWidget(self._heading_cb); hl.addStretch()
        ol.addLayout(hl)
        self._render_cb = QCheckBox("渲染 Markdown 预览")
        self._render_cb.setChecked(True); ol.addWidget(self._render_cb)
        self._image_cb = QCheckBox("嵌入图片")
        self._image_cb.setChecked(True); ol.addWidget(self._image_cb)
        self._ocr_cb = QCheckBox("启用 OCR")
        ol.addWidget(self._ocr_cb)
        ol.addStretch()
        self._convert_btn = QPushButton("开始转换")
        self._convert_btn.setObjectName("primaryAction")
        self._convert_btn.setFixedHeight(44)
        ol.addWidget(self._convert_btn)
        self._options_card.setMinimumWidth(220)
        self._inner_splitter.addWidget(self._options_card)

        # Card 3: Preview
        self._preview_card = CollapsibleCard("Markdown 预览")
        pl = self._preview_card.content_layout()
        ptb = QHBoxLayout()
        self._view_mode_btn = QPushButton("预览")
        self._view_mode_btn.setObjectName("secondaryBtn")
        self._view_mode_btn.setFixedHeight(30)
        ptb.addWidget(self._view_mode_btn)
        self._copy_btn = QPushButton("📋 复制")
        self._copy_btn.setObjectName("secondaryBtn")
        self._copy_btn.setFixedHeight(30)
        ptb.addWidget(self._copy_btn)
        self._save_btn = QPushButton("导出")
        self._save_btn.setObjectName("secondaryBtn")
        self._save_btn.setFixedHeight(30)
        ptb.addWidget(self._save_btn); ptb.addStretch()
        pl.addLayout(ptb)
        self._preview = QTextBrowser()
        self._preview.setOpenExternalLinks(True)
        pl.addWidget(self._preview)
        self._preview_card.setMinimumWidth(220)
        self._inner_splitter.addWidget(self._preview_card)

        # Wrap inner splitter + history into outer vertical splitter
        self._outer_splitter = ResettableSplitter(Qt.Vertical, default_sizes=[600, 400])
        top_container = QWidget()
        top_layout = QVBoxLayout(top_container)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.addWidget(self._inner_splitter)

        self._hist_panel = HistoryPanel()
        self._hist_panel.setMinimumHeight(180)

        self._outer_splitter.addWidget(top_container)
        self._outer_splitter.addWidget(self._hist_panel)

        # Restore saved sizes
        saved_outer = self._settings.window_splitter_outer
        saved_inner = self._settings.window_splitter_inner
        if saved_outer:
            self._outer_splitter.restoreState(saved_outer)
        if saved_inner:
            self._inner_splitter.restoreState(saved_inner)

        root.addWidget(self._outer_splitter, 1)
        # Status Bar
        self._status = QLabel("就绪")
        self.statusBar().addWidget(self._status, 1)

        # Signals
        self._connect_signals()

        # Worker
        self._worker = ConvertWorker(self)
        self._worker.finished.connect(self._on_convert_finished)
        self._worker.error.connect(self._on_convert_error)
        self._worker.progress.connect(self._on_convert_progress)
        self._worker.started.connect(self._on_convert_started)
        self.setWindowTitle(f"{__app_name__} v{__version__}")
        geo = self._settings.window_geometry
        if geo: self.restoreGeometry(geo)
        else: self.resize(1280, 800)
        self._refresh_history()

    def _connect_signals(self):
        self._topbar.tool_button("toolOpen").clicked.connect(self._open_file)
        self._topbar.tool_button("toolConvert").clicked.connect(self._start_convert)
        self._topbar.tool_button("toolCopy").clicked.connect(self._copy_to_clipboard)
        self._topbar.tool_button("toolClear").clicked.connect(self._clear_content)
        self._topbar.tool_button("toolMD").clicked.connect(self._toggle_preview_mode)
        self._topbar.theme_btn.clicked.connect(self._theme.toggle)
        self._topbar.settings_btn.clicked.connect(self._open_settings)
        self._drop_area.file_dropped.connect(self._on_files_dropped)
        self._drop_area.browse_btn.clicked.connect(self._open_file)
        self._convert_btn.clicked.connect(self._start_convert)
        self._view_mode_btn.clicked.connect(self._toggle_preview_mode)
        self._copy_btn.clicked.connect(self._copy_to_clipboard)
        self._save_btn.clicked.connect(self._save_file)
        self._hist_panel.clear_btn.clicked.connect(self._clear_history)
        self._hist_panel.list_widget.itemClicked.connect(self._on_history_clicked)
        self._theme.theme_changed.connect(self._on_theme_changed)

    def _on_theme_changed(self, theme):
        self._topbar.update_theme_icon(theme == "dark")
        if self._current_markdown:
            self._render_markdown(self._current_markdown)

    def _open_file(self):
        filter_str = ("所有支持的文件 (*.pdf *.docx *.pptx *.xlsx *.xls "
            "*.html *.htm *.txt *.csv *.json *.xml *.md "
            "*.jpg *.jpeg *.png *.wav *.mp3 *.m4a "
            "*.msg *.epub *.zip *.rtf);;"
            "PDF (*.pdf);;Word (*.docx);;PowerPoint (*.pptx);;"
            "Excel (*.xlsx *.xls);;所有文件 (*)")
        path, _ = QFileDialog.getOpenFileName(self, "选择文件", "", filter_str)
        if path:
            self._on_files_dropped([path])

    def _on_files_dropped(self, paths):
        for p in paths:
            if os.path.isfile(p) and p not in self._file_list:
                self._file_list.append(p)
        self._refresh_file_list()
        self._status.setText(f"已加载 {len(self._file_list)} 个文件")

    def _refresh_file_list(self):
        self._file_list_w.clear()
        for p in self._file_list:
            name = os.path.basename(p)
            try:
                sz = os.path.getsize(p)
                sz_str = self._format_size(sz)
            except:
                sz_str = "?"
            item = QListWidgetItem(f"  {name}   ({sz_str})")
            item.setData(Qt.UserRole, p)
            self._file_list_w.addItem(item)

    def _start_convert(self):
        if not self._file_list:
            QMessageBox.information(self, "提示", "请先添加文件。")
            return
        self._convert_file(self._file_list[0])

    def convert_file(self, file_path):
        self._convert_file(file_path)

    def _convert_file(self, file_path):
        self._current_file = file_path
        self._convert_start = time.time()
        self._worker.start_convert(file_path)

    @Slot(str, str)
    def _on_convert_started(self, file_path, file_name):
        self._status.setText(f"正在转换: {os.path.basename(file_path)}...")
        self._convert_btn.setEnabled(False)
        self._convert_btn.setText("转换中...")

    @Slot(str)
    def _on_convert_progress(self, msg):
        self._status.setText(msg)

    @Slot(str, str)
    def _on_convert_finished(self, markdown, file_path):
        elapsed = time.time() - self._convert_start
        self._current_markdown = markdown
        self._convert_btn.setEnabled(True)
        self._convert_btn.setText("开始转换")
        self._status.setText(f"完成 ({elapsed:.1f}s)")
        self._render_markdown(markdown)
        entry = HistoryManager.make_entry(file_path, markdown)
        self.history_mgr.add(entry)
        self._refresh_history()

    @Slot(str, str)
    def _on_convert_error(self, error_msg, file_path):
        self._convert_btn.setEnabled(True)
        self._convert_btn.setText("开始转换")
        self._status.setText("转换失败")
        QMessageBox.warning(self, "转换失败", error_msg)

    def _toggle_preview_mode(self):
        txt = self._view_mode_btn.text()
        if txt == "预览":
            self._view_mode_btn.setText("源码")
            if self._current_markdown:
                self._preview.setPlainText(self._current_markdown)
        else:
            self._view_mode_btn.setText("预览")
            if self._current_markdown:
                self._render_markdown(self._current_markdown)

    def _render_markdown(self, text):
        try:
            import markdown as md_lib
            from pygments.formatters import HtmlFormatter
            extensions = ["fenced_code", "codehilite", "tables", "toc", "nl2br"]
            ext_configs = {"codehilite": {"css_class": "highlight", "use_pygments": True}}
            body_html = md_lib.markdown(text, extensions=extensions, extension_configs=ext_configs)
            pygments_css = HtmlFormatter().get_style_defs(".highlight")
        except ImportError:
            body_html = "<pre>" + html_mod.escape(text) + "</pre>"
            pygments_css = ""

        bg = self._theme.bg_color()
        fg = self._theme.text_color()
        border = self._theme.border_color()
        accent = self._theme.accent_color()

        full_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
  {pygments_css}
  body {{
    background: {bg};
    color: {fg};
    font-family: "Microsoft YaHei", "Segoe UI", system-ui, sans-serif;
    font-size: 14px;
    line-height: 1.6;
    max-width: 900px;
    margin: 0 auto;
    padding: 10px 20px;
  }}
  h1, h2, h3, h4, h5, h6 {{ color: {fg}; margin-top: 20px; }}
  h1 {{ border-bottom: 1px solid {border}; padding-bottom: 6px; font-size: 22px; }}
  h2 {{ font-size: 18px; }}
  code {{
    background: {accent}20;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.9em;
    font-family: "Consolas", "Courier New", monospace;
  }}
  pre {{
    background: {accent}08;
    border: 1px solid {border};
    border-radius: 8px;
    padding: 14px;
    overflow-x: auto;
  }}
  pre code {{ background: none; padding: 0; }}
  table {{ border-collapse: collapse; width: 100%; margin: 12px 0; }}
  th, td {{ border: 1px solid {border}; padding: 8px 12px; text-align: left; }}
  th {{ background: {accent}10; }}
  blockquote {{
    border-left: 4px solid {accent};
    margin: 12px 0;
    padding: 6px 16px;
    background: {accent}08;
  }}
  img {{ max-width: 100%; }}
  a {{ color: {accent}; }}
</style></head><body>{body_html}</body></html>"""
        self._preview.setHtml(full_html)

    def _save_file(self):
        if not self._current_markdown:
            QMessageBox.information(self, "提示", "没有可保存的内容。")
            return
        ask = self._settings.ask_save_each_time
        default_dir = self._settings.default_save_path
        if ask or not default_dir:
            suggested = "output.md"
            if self._current_file:
                base = os.path.splitext(os.path.basename(self._current_file))[0]
                suggested = base + ".md"
            path, _ = QFileDialog.getSaveFileName(self, "保存 Markdown", suggested, "Markdown (*.md);;所有文件 (*)")
        else:
            base = os.path.splitext(os.path.basename(self._current_file or "output"))[0]
            path = os.path.join(default_dir, base + ".md")
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self._current_markdown)
                self._status.setText(f"已保存: {path}")
            except OSError as e:
                QMessageBox.critical(self, "保存失败", str(e))

    def _copy_to_clipboard(self):
        if not self._current_markdown:
            QMessageBox.information(self, "提示", "没有可复制的内容。")
            return
        QApplication.clipboard().setText(self._current_markdown)
        self._status.setText("已复制到剪贴板")

    def _clear_content(self):
        self._current_file = None
        self._current_markdown = ""
        self._file_list.clear()
        self._file_list_w.clear()
        self._preview.clear()
        self._status.setText("已清空")

    def _open_settings(self):
        dlg = SettingsDialog(self._settings, self._theme, self)
        dlg.exec()
        self.history_mgr._max = self._settings.max_history

    def _clear_history(self):
        self.history_mgr.clear()
        self._refresh_history()

    def _refresh_history(self):
        self._hist_panel.list_widget.clear()
        for entry in self.history_mgr.entries:
            ts = time.strftime("%H:%M", time.localtime(entry.timestamp))
            preview = entry.output_preview[:50] if entry.output_preview else ''
            text = f"{entry.file_name}  |  {ts}  |  {preview}"
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, entry.file_path)
            item.setToolTip(entry.file_path)
            self._hist_panel.list_widget.addItem(item)
        self._hist_panel.set_count(len(self.history_mgr.entries))

    def _on_history_clicked(self, item):
        path = item.data(Qt.UserRole)
        if path and os.path.isfile(path):
            self._on_files_dropped([path])
            self._convert_file(path)

    @staticmethod
    def _format_size(size):
        for unit in ("B", "KB", "MB", "GB"):
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def closeEvent(self, event):
        self._settings.window_geometry = self.saveGeometry()
        self._settings.window_splitter_outer = self._outer_splitter.saveState()
        self._settings.window_splitter_inner = self._inner_splitter.saveState()
        self._settings.sync()
        super().closeEvent(event)

